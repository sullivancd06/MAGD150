//Establish constants. These can be edited to change the scale of the program.
//Setting these to non-integer values will result in undefined behavior.

const TILES_WIDE = 15;	//How many tiles wide the canvas is.
const TILES_HIGH = 15;	//How many tiles high the canvas is.
const TILE_SCALE = 4;	//How much to scale the 16x16 sprites loaded into the program.

//Establish global variables.

let wallTilemap;	//The composite tileset image will be loaded into this variable.
let wallTileset = [];	//The composite tileset will be sliced and stored in this array.
let hasWall = [];	//The indecies of this array will indicate whether or not a wall exists at the corresponding tile.

function preload(){
	//Load the image for the wall tileset and store it in the wallTileMap variable.
	wallTileMap = loadImage('assets/Wall_Tileset.png');
}

function setup(){
	//Build the canvas, at a size specified by global constants.
	createCanvas(TILES_WIDE * TILE_SCALE * 16, TILES_HIGH * TILE_SCALE * 16);

	//Slice the composite tileset, scale the slices, and store them in the tileset array.
	//The order in which the slices are put into the array are important. They must be inserted into
	//the array so that their indecies correspond to the decimal representation of the encoded 4-bit
	//string that represents when it will be used. Each bit represents, respectively from least to
	//most significant, a neigboring wall to the north, east, south and west.
	wallTileset.push(sharpScale(wallTileMap.get(48, 48, 16, 16), TILE_SCALE));	//00, or {0000}
	wallTileset.push(sharpScale(wallTileMap.get(48, 32, 16, 16), TILE_SCALE));	//01, or {0001}
	wallTileset.push(sharpScale(wallTileMap.get(0, 48, 16, 16), TILE_SCALE));	//02, or {0010}
	wallTileset.push(sharpScale(wallTileMap.get(0, 32, 16, 16), TILE_SCALE));	//03, or {0011}
	wallTileset.push(sharpScale(wallTileMap.get(48, 0, 16, 16), TILE_SCALE));	//04, or {0100}
	wallTileset.push(sharpScale(wallTileMap.get(48, 16, 16, 16), TILE_SCALE));	//05, or {0101}
	wallTileset.push(sharpScale(wallTileMap.get(0, 0, 16, 16), TILE_SCALE));	//06, or {0110}
	wallTileset.push(sharpScale(wallTileMap.get(0, 16, 16, 16), TILE_SCALE));	//07, or {0111}
	wallTileset.push(sharpScale(wallTileMap.get(32, 48, 16, 16), TILE_SCALE));	//08, or {1000}
	wallTileset.push(sharpScale(wallTileMap.get(32, 32, 16, 16), TILE_SCALE));	//09, or {1001}
	wallTileset.push(sharpScale(wallTileMap.get(16, 48, 16, 16), TILE_SCALE));	//10, or {1010}
	wallTileset.push(sharpScale(wallTileMap.get(16, 32, 16, 16), TILE_SCALE));	//11, or {1011}
	wallTileset.push(sharpScale(wallTileMap.get(32, 0, 16, 16), TILE_SCALE));	//12, or {1100}
	wallTileset.push(sharpScale(wallTileMap.get(32, 16, 16, 16), TILE_SCALE));	//13, or {1101}
	wallTileset.push(sharpScale(wallTileMap.get(16, 0, 16, 16), TILE_SCALE));	//14, or {1110}
	wallTileset.push(sharpScale(wallTileMap.get(16, 16, 16, 16), TILE_SCALE));	//15, or {1111}

	//Create a sub-array within the hasWall array for each column of tiles, based on the width of the
	//canvas.
	for(let i = 0; i < TILES_WIDE; i++){
		//Create the sub-array.
		let newWallArray = [];

		//Fill the array with boolean elements based on the height of the canvas.
		for(let j = 0; j < TILES_HIGH; j++){
			//Initialize the elements of the array with 'false'.
			newWallArray.push(true);
		}

		//Add the new sub-array to the hasWall array.
		hasWall.push(newWallArray);
	}	
}

function draw(){

	//Create a background so that old elements do not linger on the screen.
	background(40, 50, 50);

	//Iterate through each tile to determine where an how to draw the walls.
	for(let x = 0; x < TILES_WIDE; x++){
		for(let y = 0; y < TILES_HIGH; y++){
			//If the tile has a wall...
			if(hasWall[x][y]){
				//...find the encoded value that represents its neighbors, use that value to
				//determine which image to draw, and place that image on its tile.
				image(wallTileset[findShape(x, y)], x * TILE_SCALE * 16, y * TILE_SCALE * 16);
			}
		}
	}
}

function mouseClicked(){
	//Determine which tile the user clicked on.
	let x = (mouseX - (mouseX % (TILE_SCALE * 16))) / (TILE_SCALE * 16);
	let y = (mouseY - (mouseY % (TILE_SCALE * 16))) / (TILE_SCALE * 16);

	//If the tile is on the canvas...
	if(x >= 0 && x < TILES_WIDE && y >= 0 && y < TILES_HIGH){
		//...toggle whether or not that tile has a wall.
		hasWall[x][y] = !hasWall[x][y];
	}
}

function findShape(x, y){

	//This function checks to see there are any walls present on the tiles
	//adjacent to the imput tile (x, y) and returns a value representing the
	//location of any such walls.

	//Input: the number of tiles from the left (x) of the tile to be checked, and
	//its number of tiles from the top (y).

	//Output: an encoded value (shapeValue) representing where neighboring walls
	//exist.

	//Create the output value and initialize it to 0. This can be seen as a string
	//of binary digits representing whether or not there is a wall in each
	//adjacent tile. It defaults to {0000}, as it assumes there are no neighboring
	//walls unless proven otherwise.
	let shapeValue = 0;

	//If the tile is not on the top edge of the map and has a wall to the north...
	if(y > 0 && hasWall[x][y - 1]){
		//...increment the encoded value by 1. This can be seen as incrementing
		//the fourth binary digit in the above mentioned string, or adding
		//{0001}.
		shapeValue +=1;
	}

	//If the tile is not on the right edge of the map and has a wall to the east...
	if(x < TILES_WIDE - 1 && hasWall[x + 1][y]){
		//...increment the encoded value by 2. This can be seen as incrementing
		//the third binary digit in the above mentioned string, or adding
		//{0010}.
		shapeValue += 2;
	}

	//If the tile is not on the bottom edge of the map and has a wall to the south...
	if(y < TILES_HIGH - 1 && hasWall[x][y + 1]){
		//...increment the encoded value by 4. This can be seen as incrementing
		//the second binary digit in the above mentioned string, or adding
		//{0100}.
		shapeValue += 4;
	}

	//If the tile is not on the left edge of the map and has a wall to the west...
	if(x > 0 && hasWall[x - 1][y]){
		//...increment the encoded value by 8. This can be seen as incrementing
		//the first binary digit in the above mentioned string, or adding
		//{1000}.
		shapeValue +=8;
	}

	//Return the encoded value.
	return shapeValue;
}

function sharpScale(img, s){

	//This function scales up a pixel art image so that it can take up more space
	//on the screen and become more readable. This a preferable alternative to
	//p5.js's "resize" function because it keeps the sharp, clean edges of the
	//pixel art.

	//Input: an image (img) to be scaled, and an integer (s) by which to scale the
	//image.

	//Output: an image (scaledImg) with a length and width larger than that of the
	//input image by a factor of s.

	//Create the new empty image to which pixels will be copied.
	let scaledImg = createImage(img.width * s, img.height * s);

	//Make sure the pixels of both the input and output images are loaded and
	//available to be manipulated.
	img.loadPixels();
	scaledImg.loadPixels();

	//Iterate over each pixel in the original image.
	for(let x = 0; x < img.width; x++){
		for(let y = 0; y < img.height; y++){

			//Create and an array to represent the RGBA value of the
			//currently selected pixel.
			let pixel = [];

			//Locate the donor pixel.
			let index = 4 * (x + y * img.width);

			//Copy its RGBA values into the array.
			pixel.push(img.pixels[index]);
			pixel.push(img.pixels[index + 1]);
			pixel.push(img.pixels[index + 2]);
			pixel.push(img.pixels[index + 3]);

			//Iterate over each pixel in the new image to be copied to.
			for(let x2 = 0; x2 < s; x2++){
				for(let y2 = 0; y2 < s; y2++){

					//Locate the recepient pixel.
					newX = x * s + x2;
					newY = y * s + y2;
					index = 4 * (4 * newY * img.width + newX);

					//Copy the donor pixel's RGBA values into the
					//recipient.
					scaledImg.pixels[index] = pixel[0];
					scaledImg.pixels[index + 1] = pixel[1];
					scaledImg.pixels[index + 2] = pixel[2];
					scaledImg.pixels[index + 3] = pixel[3];
				}
			}
		}
	}

	//Make sure the new pixels are loaded into the output image.
	scaledImg.updatePixels();

	//Return the output image.
	return scaledImg;
}