const xscale = 1.25;
const yscale = 1;
const camLateralMove = 16;
const camForwardMove = 16;
const whiteshift = 30;

let tutorial = true;
let tutText;

let camera = 
{
	posX: 0,
	posY: -64,
	posZ: 0,
	rotX: 0,
	rotY: 0,
	rotZ: 0,
	height: 128*yscale,
	width: 128*xscale,
	focalLength: 128*xscale
};

let polys =
[
	{
		vector1x: -1000,
		vector1y: 16,
		vector1z: 1000,

		vector2x: 1000,
		vector2y: 16,
		vector2z: 1000,

		vector3x: -1000,
		vector3y: 16,
		vector3z: -1000,

		color: 0
	},
	{
		vector1x: 1000,
		vector1y: 16,
		vector1z: -1000,

		vector2x: -1000,
		vector2y: 16,
		vector2z: -1000,

		vector3x: 1000,
		vector3y: 16,
		vector3z: 1000,

		color: 0
	}
];

function setup()
{
	createCanvas(128*xscale, 128*yscale);
  
    tutText = createDiv('Tap the arrow keys.');
    tutText.position((width-128)/2, height - 24);
  
	addCube(1, 256, 950, 64, 512, 64);
  	addCube(1, 506, 960, 64, 512, 64);
  	addCube(1, -256, 930, 72, 412, 72);
    addCube(1, -390, 950, 64, 380, 72);
    addCube(1, -750, 910, 64, 432, 64);
    addCube(1, 680, 900, 72, 360, 72);
    addCube(1, 120, 860, 72, 320, 72);
    addCube(1, -120, 880, 72, 310, 142);
    addCube(1, -580, 850, 216, 300, 72);
    addCube(1, 530, 845, 144, 310, 64);
    addCube(1, 270, 750, 256, 220, 72);
    addCube(1, -320, 720, 256, 200, 72);
    addCube(1, -700, 690, 270, 170, 72);
    addCube(1, 710, 680, 290, 180, 94);
    addCube(1, -480, 620, 94, 280, 72);
    addCube(1, 780, 550, 94, 280, 72);
    addCube(1, -142, 550, 112, 128, 200);
    addCube(1, 133, 550, 94, 120, 200);
    addCube(1, 360, 595, 220, 150, 72);
    addCube(1, -430, 520, 300, 142, 94);
    addCube(1, -790, 490, 112, 220, 94);
    addCube(1, 520, 480, 300, 120, 94);
    addCube(1, 260, 450, 94, 220, 94);
    addCube(1, 157, 350, 142, 150, 112);
    addCube(1, -133, 380, 94, 100, 94);
    addCube(1, -150, 210, 128, 150, 128);
    addCube(1, 180, 150, 188, 110, 142);
    addCube(1, -186, 57, 200, 94, 118);
    addCube(1, 118, 40, 64, 150, 64);
    addCube(1, 275, 40, 160, 76, 64);
    addCube(1, 800, 40, 280, 108, 64);
    addCube(1, 720, 260, 220, 96, 128);
    addCube(1, 410, 40, 64, 128, 64);
    addCube(1, 550, 40, 180, 76, 64);
    addCube(1, 420, 150, 200, 88, 128);
    addCube(1, 640, 130, 72, 180, 72);
    addCube(1, -790, 56, 310, 72, 96);
    addCube(1, -930, 150, 72, 200, 72);
    addCube(1, -760, 290, 360, 108, 64);
    addCube(1, -600, 340, 96, 180, 72);
    addCube(1, -560, 160, 280, 64, 64);
    addCube(1, -510, 40, 120, 96, 64);
    addCube(1, -370, 56, 140, 72, 96);
    addCube(1, -290, 270, 96, 180, 96);
    
}

function addCube(material, posX, posZ, scaleX, scaleY, scaleZ)
{
    posY = -(scaleY/2 - 16)
	polys.push
	({
		vector1x: posX - scaleX/2,
		vector1y: posY + scaleY/2,
		vector1z: posZ - scaleZ/2,

		vector2x: posX + scaleX/2,
		vector2y: posY + scaleY/2,
		vector2z: posZ - scaleZ/2,

		vector3x: posX - scaleX/2,
		vector3y: posY - scaleY/2,
		vector3z: posZ - scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX + scaleX/2,
		vector1y: posY - scaleY/2,
		vector1z: posZ - scaleZ/2,

		vector2x: posX - scaleX/2,
		vector2y: posY - scaleY/2,
		vector2z: posZ - scaleZ/2,

		vector3x: posX + scaleX/2,
		vector3y: posY + scaleY/2,
		vector3z: posZ - scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX - scaleX/2,
		vector1y: posY + scaleY/2,
		vector1z: posZ + scaleZ/2,

		vector2x: posX - scaleX/2,
		vector2y: posY + scaleY/2,
		vector2z: posZ - scaleZ/2,

		vector3x: posX - scaleX/2,
		vector3y: posY - scaleY/2,
		vector3z: posZ + scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX - scaleX/2,
		vector1y: posY - scaleY/2,
		vector1z: posZ - scaleZ/2,

		vector2x: posX - scaleX/2,
		vector2y: posY - scaleY/2,
		vector2z: posZ + scaleZ/2,

		vector3x: posX - scaleX/2,
		vector3y: posY + scaleY/2,
		vector3z: posZ - scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX - scaleX/2,
		vector1y: posY - scaleY/2,
		vector1z: posZ - scaleZ/2,

		vector2x: posX + scaleX/2,
		vector2y: posY - scaleY/2,
		vector2z: posZ - scaleZ/2,

		vector3x: posX - scaleX/2,
		vector3y: posY - scaleY/2,
		vector3z: posZ + scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX + scaleX/2,
		vector1y: posY - scaleY/2,
		vector1z: posZ + scaleZ/2,

		vector2x: posX - scaleX/2,
		vector2y: posY - scaleY/2,
		vector2z: posZ + scaleZ/2,

		vector3x: posX + scaleX/2,
		vector3y: posY - scaleY/2,
		vector3z: posZ - scaleZ/2,

		color: material
	});


	polys.push
	({
		vector1x: posX + scaleX/2,
		vector1y: posY + scaleY/2,
		vector1z: posZ + scaleZ/2,

		vector2x: posX + scaleX/2,
		vector2y: posY + scaleY/2,
		vector2z: posZ - scaleZ/2,

		vector3x: posX + scaleX/2,
		vector3y: posY - scaleY/2,
		vector3z: posZ + scaleZ/2,

		color: material
	});

	polys.push
	({
		vector1x: posX + scaleX/2,
		vector1y: posY - scaleY/2,
		vector1z: posZ - scaleZ/2,

		vector2x: posX + scaleX/2,
		vector2y: posY - scaleY/2,
		vector2z: posZ + scaleZ/2,

		vector3x: posX + scaleX/2,
		vector3y: posY + scaleY/2,
		vector3z: posZ - scaleZ/2,

		color: material
	});
}

function draw()
{
  	background(0);
    strokeWeight(1);
    strokeCap(SQUARE);
  	for(let x = 0; x < camera.width; x++)
	{
    		for(let y = 0; y < camera.height; y++)
		{
      			let ray =
			{
				posX: camera.posX,
				posY: camera.posY,
				posZ: camera.posZ - camera.focalLength,

				rotX: 0,
				rotY: 0,
				rotZ: 0,
      			}

			ray.rotX = (camera.posX + x - (camera.width - 1) / 2) - ray.posX;	
			ray.rotY = (camera.posY + y - (camera.height - 1) / 2) - ray.posY;
			ray.rotZ = (camera.posZ) - ray.posZ;

      			stroke(rayTrace(ray, polys));
      			point(x, y);
    		}
  	}
  
    if(tutorial)
    {
      strokeWeight(2);
      strokeCap(ROUND);
      stroke(1);
      fill(255);
      rect((width - 132)/2, height - 24, 132, 18);
      noStroke();
      fill(230)
      ellipse(width/2, height - 9, 128, 4);
    }
    else
    {
      tutText.html('');
    }
}

function rayTrace(ray, polys)
{
  	let colorValue = 220;
  	let planarHits = [];
	let planarHitsI = 0;
	let closestPolyHit = -1;
  
  	polys.forEach(element =>
	{
      		let AX = element.vector2x - element.vector1x;
      		let AY = element.vector2y - element.vector1y;
      		let AZ = element.vector2z - element.vector1z;
      
      		let BX = element.vector3x - element.vector1x;
      		let BY = element.vector3y - element.vector1y;
      		let BZ = element.vector3z - element.vector1z;
      
      		let n =
		{
			X: BY * AZ - BZ * AY,
            		Y: BZ * AX - BX * AZ,
            		Z: BX * AY - BY * AX
		};
      
		let ln = dotProduct(ray.rotX, ray.rotY, ray.rotZ, n.X, n.Y, n.Z);
		let d = 0;

		if(ln != 0)
		{
			let pln = dotProduct(element.vector1x - ray.posX, element.vector1y - ray.posY, element.vector1z - ray.posZ, n.X, n.Y, n.Z);
			d = pln / ln;
		}

		if (d > 0)
		{
			planarHits.push({poly: element, distance: d, normal: n});
		}
	});

	planarHits.forEach(element =>
	{
		if(closestPolyHit == -1 || planarHits[closestPolyHit].distance > element.distance)
		{
			let pX = ray.posX + element.distance * ray.rotX;
			let pY = ray.posY + element.distance * ray.rotY;
			let pZ = ray.posZ + element.distance * ray.rotZ;
          
            		let APX = pX - element.poly.vector1x;
            		let APY = pY - element.poly.vector1y;
            		let APZ = pZ - element.poly.vector1z;
          
            		let ABX = element.poly.vector2x - element.poly.vector1x;
            		let ABY = element.poly.vector2y - element.poly.vector1y;
            		let ABZ = element.poly.vector2z - element.poly.vector1z;

			let CrossAX = ABY * APZ - ABZ * APY;
			let CrossAY = ABZ * APX - ABX * APZ;
			let CrossAZ = ABX * APY - ABY * APX;
          
            		let checkA = (dotProduct(CrossAX, CrossAY, CrossAZ, element.normal.X, element.normal.Y, element.normal.Z) <= 0);

			let BPX = pX - element.poly.vector2x;
			let BPY = pY - element.poly.vector2y;
			let BPZ = pZ - element.poly.vector2z;
          
            		let BCX = element.poly.vector3x - element.poly.vector2x;
            		let BCY = element.poly.vector3y - element.poly.vector2y;
            		let BCZ = element.poly.vector3z - element.poly.vector2z;

			let CrossBX = BCY * BPZ - BCZ * BPY;
			let CrossBY = BCZ * BPX - BCX * BPZ;
			let CrossBZ = BCX * BPY - BCY * BPX;
          
            		let checkB = (dotProduct(CrossBX, CrossBY, CrossBZ, element.normal.X, element.normal.Y, element.normal.Z) <= 0);

			let CPX = pX - element.poly.vector3x;
            		let CPY = pY - element.poly.vector3y;
            		let CPZ = pZ - element.poly.vector3z;
          
            		let CAX = element.poly.vector1x - element.poly.vector3x;
            		let CAY = element.poly.vector1y - element.poly.vector3y;
            		let CAZ = element.poly.vector1z - element.poly.vector3z;
          
            		let CrossCX = CAY * CPZ - CAZ * CPY;
            		let CrossCY = CAZ * CPX - CAX * CPZ;
            		let CrossCZ = CAX * CPY - CAY * CPX;
          
            		let checkC = (dotProduct(CrossCX, CrossCY, CrossCZ, element.normal.X, element.normal.Y, element.normal.Z) <= 0);
            
			if(checkA && checkB && checkC)
			{
				closestPolyHit = planarHitsI;
			}
		}
		planarHitsI++
	});

	if(closestPolyHit >= 0)
	{
		colorValue = planarHits[closestPolyHit].poly.color + planarHits[closestPolyHit].distance * whiteshift;
	}

	return colorValue; 
}

function dotProduct(v1x, v1y, v1z, v2x, v2y, v2z)
{
	return (v1x * v2x + v1y * v2y + v1z * v2z);
}

function keyPressed()
{
	switch (keyCode)
	{
		case 65:
		case 37:
			camera.posX -= camLateralMove;
            tutorial = false;
			break;
		case 68:
		case 39:
			camera.posX += camLateralMove;
            tutorial = false;
			break;
		case 87:
		case 38:
			camera.posZ += camForwardMove;
            tutorial = false;
			break;
		case 83:
		case 40:
			camera.posZ -= camForwardMove;
            tutorial = false;
			break;
	}
}