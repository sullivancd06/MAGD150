const canvasX = 400;
const canvasY = 400;
const spinSpeed = 0.1;

let play = true;
let mouseOverPlay = false;
let mouseOverGenerate = false;

let planet;
let planetR;
let planetX;
let planetY;
let perlinSphereMap;


function setup() {
  cnv = createCanvas(canvasX, canvasY);
  cnv.mouseClicked(mouseAction);
  
  colorMode(RGB, 255, 255, 255, 1);
  
  planet = generatePlanet();
  
  planetR = 0.3 * min(height, width);
  planetX = 0.5 * width;
  planetY = 0.5 * height;
  
  perlinSphereMap = new Array(2 * planetR);
  
  for(let x = 0; x < perlinSphereMap.length; x++){
    perlinSphereMap[x] = new Array(2 * planetR);
    
    for(let y = 0; y < perlinSphereMap[x].length; y++){
      let param1 = pow(x - planetR, 2) + pow(y - planetR, 2) <= pow(planetR, 2);
      let param2 = 2 * pow(x - planetR, 2) + pow(y - planetR, 2) > pow(planetR, 2);
      let param3 = x < planetR;
      
      if(param1 && !(param2 && param3)){
        perlinSphereMap[x][y] = sqrt(pow(planetR, 2) - pow(x - planetR, 2) - pow(y - planetR, 2));
      }
      else{
        perlinSphereMap[x][y] = -1;
      }
    }
  }
}

function draw() {
  background(0, 0, 0, 1);
  
  strokeWeight(1);
  
  for(let x = 0; x < perlinSphereMap.length; x++){
    for(let y = 0; y < perlinSphereMap[x].length; y++){
        if(perlinSphereMap[x][y] != -1){
          let pointColor = planet.colorAt(x - planetR, y - planetR, perlinSphereMap[x][y]);
          stroke(pointColor[0], pointColor[1], pointColor[2], 1);
          point(x - planetR + planetX, y - planetR + planetY);
      }
    }
  }
  
 //determine if mouse is over the UI
  if(mouseX >= width - 64 && mouseY >= height - 32){
   //determine which command the mouse is over
    if(mouseX >= width - 32){
      //over the play button
      mouseOverPlay = true;
      mouseOverGenerate = false;
    }
    else{
      //over the generate button
      mouseOverGenerate = true;
      mouseOverPlay = false;
    }
  }
  else{
    mouseOverPlay = false;
    mouseOverGenerate = false;
  }
  
  strokeWeight(2)
  
  if(mouseOverPlay){
    stroke(240, 180, 20, 1);
  }
  else{
    stroke(120, 120, 120, 1);
  }
  
  if(play){
    planet.rotate();
    quad(width - 27, height - 26, width - 18, height - 26, width - 18, height - 6, width - 27, height - 6);
    quad(width - 14, height - 26, width - 5, height - 26, width - 5, height - 6, width - 14, height - 6)
  }
  else{
    triangle(width - 27, height - 26, width - 5, height - 16, width - 27, height - 6);
  }
  
  if(mouseOverGenerate){
    stroke(240, 180, 20, 1);
  }
  else{
    stroke(120, 120, 120, 1);
  }
  
  arc(width - 50, height - 14, 18, 18, 0, 2 * PI);
  beginShape();
  vertex(width - 45, height - 27);
  vertex(width - 40, height - 27);
  vertex(width - 40, height - 24);
  vertex(width - 37, height - 24);
  vertex(width - 37, height - 19);
  vertex(width - 40, height - 19);
  vertex(width - 40, height - 16);
  vertex(width - 45, height - 16);
  vertex(width - 45, height - 19);
  vertex(width - 48, height - 19);
  vertex(width - 48, height - 24);
  vertex(width - 45, height - 24);
  endShape();  
}

function biasDownRandom(min, max){
  //returns a random number between min(inclusive) and max(exclusive)
  //this number will probably be closer to min than to max
  
  //first we generate two random numbers such that 0 <= x < 1
  
  let rn1 = random();
  let rn2 = random();
  
  //we then calculate the absolute difference of these two numbers.
  
  let downBias = abs(rn1 - rn2);
  
  //we then use that number to lerp between min and max, and return the result
  
  return lerp(min, max, downBias);
}

function biasMidRandom(min, max){
  //returns a random number between min(exclusive) and max(inclusive)
  //this number will probably be closer to the center than to either min or max
  
  //first we generate two random numbers such that 0 < x <= 1
  
  let rn1 = 1 - random();
  let rn2 = 1 - random();
  
  //we then calculate the average of these two numbers
  
  let midBias = (rn1 + rn2) / 2;
  
  //we then use that number to lerp between min and max, and return the result
  
  return lerp(min, max, midBias);
}

function mouseAction(){
  //if the user clicks the play button, toggle play
  if(mouseOverPlay){
    play = !play;
  }
  //if the user clicks the generate button, generate new planet
  else if(mouseOverGenerate){
    planet = generatePlanet();
  }
}

function generatePlanet(){
  //this is a factory function to randomly generate Planet objects
  
  let Planet = {
    //the planet's current rotation
    planetRotation: 0,
    //the clouds' current rotation
    cloudRotation: 0,
    //how much the clouds' pattern has changed
    cloudDelta: 0,
    //the planet's angular momentum
    planetSpin: biasMidRandom(0.2, 0.8),
    //the clouds' counter momentum
    cloudSpin: biasDownRandom(0, 0.5),
    //how quickly the clouds change
    cloudDeltaDelta: biasDownRandom(0, 2.5),
    //the (approximate) percentage of the planet covered by land
    landmass: biasMidRandom(0.1, 0.9),
    //the (approximate) percentage of the planet covered by clouds
    clouds: biasDownRandom(0.1, 0.5),
    //coordinates for the center of the planet's perlin land texture
    //mid and max values for the random function are arbitrary
    pLandX: random(-1024, 1024),
    pLandY: random(-1024, 1024),
    pLandZ: random(-1024, 1024),
    //cooridantes for the center of the planet's perlin cloud texture
    //random values intentionally exclude the space of the land texture,
    //but are otherwise arbitrary
    pCloudX: random(1024, 2048),
    pCloudY: random(-1024, 1024),
    pCloudZ: random(-1024, 1024),
    //base color values for the planet's terrain
    //values are on a scale from 0 to 255
    landBaseR: biasMidRandom(80, 160),
    landBaseG: biasMidRandom(80, 160),
    landBaseB: biasDownRandom(30, 125),
    //color values for the planet's water
    //values are on a scale from 0 to 255
    waterR: biasDownRandom(30, 125),
    waterG: biasMidRandom(80, 215),
    waterB: biasMidRandom(80, 215),
    //the difference in color between the poles (modified) and equator (base)
    //values modify the original land color value
    landPolarR: biasMidRandom(-15, 15),
    landPolarG: biasMidRandom(-15, 15),
    landPolarB: biasMidRandom(-15, 15),
    //the amount of variance in color from perlin noise
    //values modify the original land color value
    landPerlinR: biasMidRandom(-120, 120),
    landPerlinG: biasMidRandom(-120, 120),
    landPerlinB: biasMidRandom(-50, 15),
    //the amount of variance in color from altitude
    //values modify the original land color value
    landHeightR: biasMidRandom(-30, 30),
    landHeightG: biasDownRandom(-60, 20),
    landHeightB: biasDownRandom(-60, 20),
    
    //a function to increment the rotation variables of the planet
    rotate: function(){
      this.planetRotation += this.planetSpin * spinSpeed;
      this.cloudRotation += (this.planetSpin - this.cloudSpin) * spinSpeed;
      this.cloudDelta += this.cloudDeltaDelta
      
      this.planetRotation %= 2*PI;
      this.cloudRotation %= 2*PI;
    },
    
    //a function to determine the color of the planet at a given point
    colorAt: function(x, y, z){
      //initialize return variables
      let R = 255;
      let G = 0;
      let B = 0;
      
      //transform x and z to match cloud rotation
      let rX = x * cos(this.cloudRotation) - z * sin(this.cloudRotation);
      let rZ = z * cos(this.cloudRotation) + x * sin(this.cloudRotation);
      
      //find cloud noise variables
      let cloudNoiseX = (rX + this.pCloudX + this.cloudDelta) * 0.007;
      let cloudNoiseY = (y + this.pCloudY) * 0.04;
      let cloudNoiseZ = (rZ + this.pCloudZ) * 0.007;
      let cloudNoise = noise(cloudNoiseX, cloudNoiseY, cloudNoiseZ);
      
      //first, determine if the point is covered by clouds
      if(cloudNoise <= this.clouds){
        //determine the color of the clouds
        //first scale the noise of the clouds
        let cloudNoiseScaled = cloudNoise/this.clouds;
        //then lerp the noise to determine color
        let cloudColor = lerp(150, 255, cloudNoiseScaled);
        R = cloudColor - 25;
        G = cloudColor - 10;
        B = cloudColor;
      }
      //otherwise, we're looking at the planet
      else{
        //transform x and z to match planet rotation
        rX = x * cos(this.planetRotation) - z * sin(this.planetRotation);
        rZ = z * cos(this.planetRotation) + x * sin(this.planetRotation);
        
        //find land noise variables
        let landNoiseX = (rX + this.pLandX) * 0.01;
        let landNoiseY = (y + this.pLandY) * 0.01;
        let landNoiseZ = (rZ + this.pLandZ) * 0.01;
        let landNoise = noise(landNoiseX, landNoiseY, landNoiseZ);
        
        //next we need to determine if we're looking at water
        if(landNoise > this.landmass){
          //determine the color of the water
          //first scale the noise of the water
          let waterNoiseScaled = (landNoise - this.landmass)/(1 - this.landmass);
          //then use the scaled noise to scale the colors
          R = lerp(this.waterR, 0, waterNoiseScaled);
          G = lerp(this.waterG, this.waterG * 0.25, waterNoiseScaled);
          B = lerp(this.waterB, this.waterB * 0.75, waterNoiseScaled);
        }
        //otherwise it's land
        else{
          //set colors to their base value
          R = this.landBaseR;
          G = this.landBaseG;
          B = this.landBaseB;
          
          //determine distance from equator
          let latitude = abs(y - planetR) / planetR;
          
          //scale color shifts to latitude and add to base
          R += lerp(0, this.landPolarR, latitude);
          G += lerp(0, this.landPolarG, latitude);
          B += lerp(0, this.landPolarB, latitude);
          
          //find color noise variables
          let redNoise = noise(landNoiseX - 1024, landNoiseY, landNoiseZ);
          let greenNoise = noise(landNoiseX, landNoiseY - 1024, landNoiseZ);
          let blueNoise = noise(landNoiseX, landNoiseY, landNoiseZ - 1024);
          
          //scale color shifts to noise and add to base
          R += lerp(0, this.landPerlinR, redNoise);
          G += lerp(0, this.landPerlinG, greenNoise);
          B += lerp(0, this.landPerlinB, blueNoise);
          
          //scale land noise
          let altitude = 1 - (landNoise/this.landmass);
          
          //scale color shifts to altitude and add to base
          R += lerp(0, this.landHeightR, altitude);
          G += lerp(0, this.landHeightG, altitude);
          B += lerp(0, this.landHeightB, altitude);
        }
      }
      
      //return the values as an array
      return [R, G, B];
    }
  };
  return Planet;
}